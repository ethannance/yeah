# concert-sponsor
A simple Node application starter template for a dynamic website backed by AWS RDS
